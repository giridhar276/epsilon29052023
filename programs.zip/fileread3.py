



#write a program to read adult.csv file and display age and workclass columns info

# read the file using csv library
import csv
with open('adult.csv','r') as fobj:
    # convert file object to the csv object
    reader = csv.reader(fobj)  
    for line in reader:
        age = line[0]
        workclass = line[1]
        print(age,workclass)