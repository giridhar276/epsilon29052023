a = 10
b = 2
if a > b :
    #inside if
    print('A > B')
    print('inside if')
    print('Still inside if')
else:
    print('B > A')
    print('inside else')
    print('Still inside else')
################################################################################    
name ='python programming'
print(name.startswith(('p')))

if name.startswith('p'):
    print("its python")
    print('inside if')
else:
    print('its unix')
    print('inside else')
################################################################################
if name.endswith('g'):
    print('string is ending with g')
    print('inside if')
else:
    print('string is something else')
    print('inside else')
################################################################################    
aname = 'python'
if aname.isupper():
    print('string is upper')
else:
    print('string is lower')
    
name ='python programming'
if  len(name) == 18:
    print('its 18 characters')
else:
    print('something else')
################################################################################
lang = input('Enter any language:')
print(lang)
if lang == 'python':
    print('you entered python')
elif lang == 'unix':
    print('you entered unix')
elif lang == 'spark':
    print('you entered spark')
elif lang == 'scala':
    print('you entered scala')
else:
    print('Its someother language')
print('regular code')
############################################################################
# for loop with string
name = 'python'
for i  in name:
    print(i)
# display numbers from 1 to 10
for val in range(1,11):    # range(start,stop,step)
    print(val)
# for loop with list
alist = [10,20,30]
for val in alist:
    print(val)
# display all even numbers
for val in range(2,11,2):
    print(val)
    
for val in range(11,0,-1):
    print(val)
    
    








