###################### user defined function ################

def display(a,b):   
    print(a,b)
display(10,20)
################# fixed arguments ################
def display(a,b):
    print(a,b)
display(10,20)
display(100,200)
################# default arguments ######################
def display(a=0,b=0,c=0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

print(list(range(5))) # default start =0  stop = 5  step = 1
print(list(range(2,5))) #  start =2  stop = 5  step = 1
print(list(range(2,5,2))) #  start =2  stop = 5  step = 2

################# keyword arguments #################

def display(c,a,b):
    print(a,b,c)
    
display(a=10,b=20,c=30)

    
################## variable length arguments #################
def display(*kargs):
    print(kargs)
display(10,20,30,40,50,45,23,56,23,67,23,67,32,76,12,81,45,3,35,34,3,34,23,3,43)

def display(*kargs):
    for val in kargs:
        print(val)
display(10,20,30,40,50,45,23,'java',23,67,23,67,32,'unix',12,81,45,3,35,34,3,34,23,3,43)







