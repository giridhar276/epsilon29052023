
import json
try:
    with open('sample2.json','r') as fobj:
        # convert file object to json object
        data = json.load(fobj)
        for key,value in data.items():
            print(key,value)
except Exception as err:
    print('Error found.. file not found')            
    print(err) 
#######################################################
import json
try:
    with open('sample211.json','r') as fobj:
        # convert file object to json object
        data = json.load(fobj)
        for key,value in data.items():
            print(key,value)
except FileNotFoundError as err:
    print('Error found.. file not found')            
    print(err)
except TypeError as err:
    print('Invalid operation')
    print(err)
except ValueError as err:
    print('Invalid input')
    print(err)
except (IndexError,KeyError) as err:
    print('Invalid index or key')
    print(err)
except Exception as err:
    print(err)
    
####################################################

# try-except-else-finally
import json
try:
    fobj =  open('sample211.json','r')

except Exception as err:
    print('Error found.. file not found')            
    print(err) 

else:
    #convert file object to json object
    data = json.load(fobj)
    for key,value in data.items():
        print(key,value)
finally:
    print('end of the file handling')
    
    
    
    
