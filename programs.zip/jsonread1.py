



import json
with open('sample2.json','r') as fobj:
    # convert file object to json object
    data = json.load(fobj)
    for key,value in data.items():
        print(key,value)