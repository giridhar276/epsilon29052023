
# write mode
fobj = open('languages.txt','w')
# operation
fobj.write('python programming\n')
fobj.write('unix shell\n')
fobj.close()


# append mode
fobj = open('languages.txt','a')
# operation
fobj.write('java programming\n')
fobj.write('ruby \n')
fobj.close()


# write the numbers from 1 to 10 to the file
fw = open('numbers.txt','w')
for num in range(1,11):
    fw.write(num + "\n")
fw.close()