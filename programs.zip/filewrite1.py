
# write mode
fobj = open('languages.txt','w')
# operation
fobj.write('python programming\n')
fobj.write('unix shell\n')
fobj.close()


# append mode
fobj = open('languages.txt','a')
# operation
fobj.write('java programming\n')
fobj.write('ruby \n')
fobj.close()


# write the numbers from 1 to 10 to the file
fw = open('numbers.txt','w')
for num in range(1,11):
    fw.write(num + "\n")
fw.close()


############ If the file is in different path
# write mode
#fobj = open('C:/Users/Administrator/Desktop/programs/examples/languages.txt','w')
#fobj = open(r'C:\Users\Administrator\Desktop\programs\examples\languages.txt','w')   # raw string
fobj = open('C:\\Users\\Administrator\\Desktop\\programs\\examples\\languages.txt','w')
# operation
fobj.write('python programming\n')
fobj.write('unix shell\n')
fobj.close()




# tradtional way
fobj = open('languages1.txt','w')
# operation
fobj.write('python programming\n')
fobj.write('unix shell\n')
fobj.close()


# pythoic way
# context manger
# If any line starts with the keyword with ... we call it as context manager
# If is not required to close the file .. file will be closed automatically when it comes out of context
with open('languages1.txt','w') as fobj:
    # operation
    fobj.write('python programming\n')
    fobj.write('unix shell\n')
    
    
    






    
    
















