


book = {"chap1":[10,'UK','Mark'] ,"chap2":[20,'US','Pet']}

book['chap1'].append('400pages')
book['chap2'].append('200pages')

print(book)

book['chap1'][0] = 100
print(book)

book['chap1'].pop(2)

print(book)


book['chap1'].insert(0,1000)
print(book)