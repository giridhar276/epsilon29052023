book = {"chap1":10 ,"chap2":20 ,"chap3":30,'chap1':100}
print(book)
# add new key-value to dictionary
book['chap4'] = 40
book['chap5'] = 50
print(book)
## print individual value
print(book['chap1']) # 10
print(book['chap2'])
# dsiplay keys
print(book.keys())
# display all the values    
print(book.values())
# display items
print(book.items())
#
#print(book['chap6'])
print(book.get('chap1')) # if key is existing.. will return the value
print(book.get('chap6')) # if key is not existing .. will return None

book.pop('chap1')  # chap1-100 will be removed from dictionary
print(book)

newbook = {"chap8":80,'chap9':90}
print(book)
print(newbook)
#finalbook =book + newbook
#print(finalbook)
#1st method
finalbook = {**book,**newbook}
print(finalbook)
#2nd method
book.update(newbook)
print(book)

output = (10,20) + (30,40)
print(output)



