

print('hello python')
print("python programming")

val = 10
print(val)
print('hello python')
print("python programming")

val = 10
print(val)
