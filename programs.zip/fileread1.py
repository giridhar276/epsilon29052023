# reading the file line by line
with open('languages.txt','r') as fobj:
    for line in fobj:
        line = line.strip() # remove whitespaces if any
        print(line)
        
        
# reading the file line by line from 2nd line
with open('languages.txt','r') as fobj:
    header = fobj.readline()
    for line in fobj:
        line = line.strip() # remove whitespaces if any
        print(line)
                
        
        
# reading all the lines at a time in the list format
with open('languages.txt','r') as fobj:
    print(fobj.readlines())
    
with open('languages.txt','r') as fobj:
    for line in fobj.readlines():
        print(line.strip())
# reading using fobj.read() in the single string
with open('languages.txt','r') as fobj:
    print(fobj.read())
    
# read the file using csv library
import csv
with open('languages.txt','r') as fobj:
    # convert file object to the csv object
    reader = csv.reader(fobj)  
    for line in reader:
        print(line)
# using pandas library
import pandas
df = pandas.read_csv('languages.txt', header = None)
print(df)
###### to validate whether the file is existing or not
import os
if os.path.isfile('languages1111.txt'):
    print('file exists')
else:
    print('file doesnt exist')


import pandas
df = pandas.read_csv('languages.txt', header = None)
print(df)


with open('languages.txt','r') as fobj:
    for line in fobj.readlines()[5:8]:
        print(line)
    
    
    
import csv
lines = range(3,7)
with open('languages.txt','r') as fobj:
    # convert file object to the csv object
    count = 0
    reader = csv.reader(fobj)  
    for line in reader:
        count = count + 1
        if count in lines:
            print(line)
        
        
        
        
        
        
    
    


