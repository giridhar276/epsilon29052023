



import requests
import json
url = 'https://api.github.com/'

user = 'giridhar276'
password = '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'

# just like select query
data = requests.get(url)

if data.status_code == 200 :
    info = json.loads(data.text)
    for key,value in info.items():
        print(key.ljust(20),value)