#write a program to read adult.csv file and display all the distinct occupation from the files
import csv
occupationset = set()
with open('adult.csv','r') as fobj:
    # convert file object to the csv object
    reader = csv.reader(fobj)  
    for line in reader:
        occupation = line[6]
        occupationset.add(occupation)      
#print(occupationset)     
for job in occupationset:
    print(job)
    
# using list
import csv
occupationlist = list()
with open('adult.csv','r') as fobj:
    # convert file object to the csv object
    reader = csv.reader(fobj)  
    for line in reader:
        occupation = line[6]
        if occupation not in occupationlist:
            occupationlist.append(occupation)
#print(occupationset)     
for job in occupationlist:
    print(job)
    
# using dictionary
import csv
occupationdict = dict()
with open('adult.csv','r') as fobj:
    # convert file object to the csv object
    reader = csv.reader(fobj)  
    for line in reader:
        occupation = line[6]
        occupationdict[occupation] = 1
#print(occupationset)     

for job in occupationdict:
    print(job)