


#write a program to display all the files from the current directory line by line with exception handling


import os
import sys
try:
    files = os.listdir()
    for file in files:
        print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())
    
    
    
    
import os
import sys
try:
    files = os.listdir('C:\\')
    for file in files:
        print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())    
    
    
    
# display files only   
import os
import sys
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())
    
    
    
# dsiplay directories only
import os
import sys
try:
    files = os.listdir()
    for file in files:
        if os.path.isdir(file):
            print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())
    
    
    