

import shutil
import os
try:
    source = "C:\\Users\\Administrator\\Desktop\\programs\\source\\"
    destination = "C:\\Users\\Administrator\\Desktop\\programs\\destination\\"
    
    
    for file in os.listdir(source):
        if os.path.isfile(file):
            print(file)
            shutil.copy(source + file,destination)
except Exception as err:
    print(err)
    
    
    
    
import os
try:
    val=os.listdir('C:/')
except FileNotFoundError :
    print ("Directory not exists")
else:
    for fname in val:
        print(fname)
finally:
    print('End of execution')