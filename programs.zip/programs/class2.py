





class Display:
    def displayOutput(self):
        print('python programming')
    def displayAdddress(self):
        print('Hyderabad')
    def displayCity(self):
        print('Chennai')
        
        
# creation of the object
obj1 = Display()                # alist = [10,20,30]
# invoking the methods
obj1.displayOutput()            # alist.append(20)
obj1.displayCity()
obj1.displayOutput()


obj2 = Display()
obj2.displayOutput()
obj2.displayCity()
obj2.displayOutput()