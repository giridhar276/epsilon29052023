
# constructor
# constructor is invoked automatically when object is created
# constructor is generally used to initialize the values

class Employee:
    def __init__(self,name,address):
        self.name = name
        self.address = address
        
    def displayDetails(self):
        print(self.name)
        print(self.address)
        
    
emp1 = Employee('Ram','Hyderabad')
emp1.displayDetails()

emp2 = Employee('Rao','Chennai')
emp2.displayDetails()

emp3 = Employee('Singh','Bangalore')
emp3.displayDetails()