 
    
import requests
import json
 


r = requests.get('https://api.github.com/users/giridhar276/gists', auth=('giridhar276','9ef89321ec1f8188c4b45fbc67db836da8ede3cf'))
 

info = json.loads(r.text)

for item in info:
    print(list(item['files'].keys())[0])
    print("-----------")
    


