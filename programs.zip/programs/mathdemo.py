
################################
# library  # package # module
# every library contains set of methods for some specific task
##############################


# importing particular library
# all the methods will be imported
#method1
import  math
print(math.log(2))
print(math.tan(1))



# method2
# importing with alias name
import math as m
print(m.log(2))
print(m.tan(1))

#method3
# importing required methods ONLY
# .  is not required is this case
from math import log,cos
print(log(3))
print(cos(1))

