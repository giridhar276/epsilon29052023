


import pymysql

#step 1
try:
    conn = pymysql.connect(host = 'localhost',port = 3306, user='root',password = 'Telstra71\@', database = 'information')
    
    if conn :
        #create cursor
        cursor = conn.cursor()
        #step2 : define query
        query = "insert into adultinfo values('{}','{}')".format('private', 'Mtech')
        # step 3: execute
        cursor.execute(query)
        conn.commit()
        # step4 fetch the output
        print(cursor.rowcount,"record inserted")
        #step5 - close the connection
        conn.close()

except pymysql.err.DataError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print(err)
except (TypeError,ValueError,KeyError,IndexError) as err:
    print(err)
