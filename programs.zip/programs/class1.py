


class Display:
    def displayOutput(self):
        print('python programming')
        
        
# creation of the object
obj1 = Display()                # alist = [10,20,30]
# invoking the methods
obj1.displayOutput()            # alist.append(20)


obj2 = Display()
obj2.displayOutput()