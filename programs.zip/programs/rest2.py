
# url/endpoint

import requests
import json
url = 'https://api.github.com/'

user = 'giridhar276'
password = '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'
endpoint = "users"
finalurl = url + endpoint
print(finalurl)


# just like select query
data = requests.get(finalurl,auth=(user,password))

if data.status_code == 200 :
    info = json.loads(data.text)
    for item in info:
        print(item['login'])
        
        
requests.get() --> select query
requets.post() --> insert query
requests.put() --> update query
requests.delete() --> delete query