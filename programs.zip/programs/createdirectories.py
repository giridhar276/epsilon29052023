
# validating before creating directory
import os

if not os.path.exists('test'):
    os.mkdir('test')
else:
    print('dir already exists')
    
    
# creating 10 directories
import os    
for val in range(1,11):
    dirname = "dir" + str(val)
    if not os.path.exists(dirname):
        os.mkdir(dirname)
    else:
        print(dirname,'already exists')



