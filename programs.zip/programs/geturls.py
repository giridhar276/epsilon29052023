
# beautifulsoup library
import requests   # reading the webpage
import bs4        # get meaningful information from the htmlpage
from bs4 import BeautifulSoup
data = requests.get('https://www.google.com/')
print(data.status_code)
# 200 - always success
if data.status_code == 200:
    soup = BeautifulSoup(data.text, 'html.parser')
    for url in soup.find_all('a'):
        print(url.get('href'))