
'''
write a program to display the below information

1) current working directory
2) login name
3) current process id
4) current python version
5) all the libraries available in python
6) all the environment variables
7) operating system name
8) platform name
9)current date and time
10)statistics of realestate.csv file
11)create empty file with today's timestamp	
'''

import os
import sys
import platform
import  datetime
#current working directory
print(os.getcwd())
#login name
print(os.getlogin())
# process
print(os.getpid())

# display version
print (sys.version_info)
# display all libraries
print(sys.modules)
# display environment variables
print(os.environ)
for key,value in os.environ.items():
    print(key,value)

print(platform.machine())
print(datetime.datetime.now())
print(os.stat('dictionary1.py'))

import time
filename = time.strftime(('%d_%b_%Y.xlsx'))
fobj = open(filename,'w')
fobj.close()



