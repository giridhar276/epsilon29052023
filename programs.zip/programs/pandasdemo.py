

import pandas as pd

df = pd.read_csv('adult.csv')
print(df['age'],df['workclass'])


