


import json
with open('sample4.json','r') as fobj:
    # convert file object to json object
    data = json.load(fobj)
    for item in data['people']:
        values = list(item.values())
        values[3] = str(values[3])
        line = ",".join(values)
        print(line)

        
import json
with open('sample4.json','r') as fobj:
    with open('samplebackup.csv','w') as fw:
        # convert file object to json object
        data = json.load(fobj)
        for item in data['people']:
            values = list(item.values())
            values[3] = str(values[3])
            line = ",".join(values)
            fw.write(line + "\n")
            


import json
with open('jsonfilewithhierarchy-100.json','r') as fobj:
    # convert file object to json object
    data = json.load(fobj)
    for item in data['feeds']:
        print(item)

