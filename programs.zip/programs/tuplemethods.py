

alist = [10,20,30]
alist[0] = 100
print(alist)


#tuple is immutable
#elements inside tuple cannot be modified directly

atup = (10,20,30)
'''
atup[0] = 100
print(atup)
'''


alist = list(atup)   # step1 : converting to list to make changes
alist.append(40)     # step2 : making changes
atup = tuple(alist)  # step3 : reconvert back to tuple
print(atup)

# tuple methods


print(atup.count(10))

# to find he index of the value
print(atup.index(30))