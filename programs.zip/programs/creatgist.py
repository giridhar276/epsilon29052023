   
import requests
import json
import time
server = "https://api.github.com"
url = server + "/gists"
user = "yourusername"
password = 'yourpassword'
print("checking ", url, "using user:", user)



local_file = "fileread1.py"
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    "fileread1.py": {
    "content": mydata
        }
      }
}

r1 = requests.post(url, data=json.dumps(files), auth=(user,password))
time.sleep(5)
print(r1.json())
