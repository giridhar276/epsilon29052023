



import shutil
import os
try:
    source = "C:\\Users\\Administrator\\Desktop\\programs\\source\\"
    destination = "C:\\Users\\Administrator\\Desktop\\programs\\destination\\"
    
    
    for file in os.listdir(source):
        #print(file)
        if os.path.isfile(destination + file):
            print('file is already existing in destination')
        else:
            shutil.copy( source + file,destination)
except Exception as err:
    print(err)
    