


import pymysql
import csv
import getpass
#step1
try:

    #password = getpass.getpass()
    conn = pymysql.connect(host = 'localhost',port = 3306, user='root',password = 'password')
    with open('adult.csv') as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            if conn :
                #create cursor
                cursor = conn.cursor()
                #step2: define query
                query = "insert into information.adultinfo values('{}','{}')".format(line[1],line[3])
                
                # step3: execute
                cursor.execute(query)
                conn.commit()
                # step4 fetch the output
                #step5 - close the connection
    conn.close()
                
except pymysql.err.DataError as err:
    print(err)
except FileNotFoundError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print(err)
except (TypeError,ValueError,KeyError,IndexError) as err:
    print(err)
except pymysql.err.MySQLError as err:
    print(err)