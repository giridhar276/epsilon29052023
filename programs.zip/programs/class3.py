


class Employee:
    def getDetails(self,name,address):
        self.name = name
        self.address = address
        
    def displayDetails(self):
        print(self.name)
        print(self.address)
        
    
emp1 = Employee()
emp1.getDetails('Ram','Hyderabad')
emp1.displayDetails()

emp2 = Employee()
emp2.getDetails('Rao','Chennai')
emp2.displayDetails()

emp3 = Employee()
emp3.getDetails('Singh','Bangalore')
emp3.displayDetails()