


book = {'chap2': 20, 'chap3': 30, 'chap4': 40, 'chap5': 50, 'chap8': 80, 'chap9': 90}

# display all the keys
for key in book:
    print(key)
    
for key in book.keys():
    print(key)
    
# display values
for value in book.values():
    print(value)
    
# display key-value
for key,value in book.items():
    print(key,value)
    
    
    
    