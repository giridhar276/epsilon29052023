




# display files only   
import os
import sys
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file.ljust(20),os.path.getsize(file),"bytes")
except Exception as err:
    print(err)
    print(sys.exc_info())