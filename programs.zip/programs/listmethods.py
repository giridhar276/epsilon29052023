alist = [34,23,4,45,1,98,65,49]
alist.append(28)
print(alist)
print('After appending',alist)
alist.extend([19,25,81])
print('After extending :',alist)
#list.insert(index,value)
alist.insert(1,100)
print('After inserting ;',alist)
#list.pop(Index)
alist.pop()  # if index is not passed , last element will be popped out
print('AFter pop :',alist)
alist.pop(1)
print('AFter pop :',alist)
alist.remove(4)  # 4 is the value existing in the list
print(alist)
#alist.remove(400)  # 4 is the value existing in the list
print(alist)

if 400 in alist:
    alist.remove(400)
else:
    print('400 doesnt exist')
    
name = 'python programming'
if 'prog' in name:
    print('substring exists')
    
print(alist)
alist.sort()
print('After sorting ;',alist)
alist.sort(reverse = True)
print('Descending order:',alist)
alist.reverse()
print('reverse order;',alist)
print('total elements :',len(alist))