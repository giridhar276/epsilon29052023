# every process contains set of system calls
# 
def display(a,b):   
     c = a + b
     return c
total = display(10,20)   
print(total)


# lambda function
# lambda is the replacement of single liner function
# inline function
# nameless function
#syntax:
#functioname = lambda variables:expression
# execution is faster compared to regular function
display = lambda x,y: x + y
total = display(10,20)   
print(total)

display = lambda x,y: 'www.' + x + y + '.com'
total = display('unix','programming')   
print(total)