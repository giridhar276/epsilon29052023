


import pymysql

#step1
try:
    conn = pymysql.connect(host = 'localhost',port = 3306, user='root',password = 'password')
    if conn :
        #create cursor
        cursor = conn.cursor()
        #step2: define query

        queries = ['select * from information.adultinfo','select * from information.adultinfo','select * from information.adultinfo']
        # step3: execute
        for query in queries:
            cursor.execute(query)
            for record in cursor.fetchall():
                print(record[0])
                print(record[1])
                print("--------")
        # step4 fetch the output
        #step5 - close the connection
        conn.close()
except pymysql.err.DataError as err:
    print(err)
except pymysql.err.DatabaseError as err:
    print(err)
except pymysql.err.OperationalError as err:
    print(err)
except (TypeError,ValueError,KeyError,IndexError) as err:
    print(err)
except pymysql.err.MySQLError as err:
    print(err)