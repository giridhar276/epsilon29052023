


#write a program to displlay all the lines to the lower case and diplay it to the screen


with open('adult11.csv','r') as fobj:
    for line in fobj:
        line = line.strip().lower() # remove whitespaces if any
        print(line)
print('logic2')
        
        
        
        
        
with open('adult.csv','r') as fobj:
    with open('adult_lower.csv','w') as fw:
        for line in fobj:
            line = line.strip().lower() # remove whitespaces if any
            fw.write(line + "\n")