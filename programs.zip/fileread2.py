


# read the file using csv library
import csv
with open('adult.csv','r') as fobj:
    # convert file object to the csv object
    reader = csv.reader(fobj)  
    for line in reader:
        print(line)